import type { Ctx } from '@milkdown/kit/ctx';
import type { MilkdownError } from '@milkdown/kit/exception';
import type { AIProvider, AIPromptContext, RunAIOptions } from './types';
export declare const aiProviderConfig: import("@milkdown/utils").$Ctx<{
    provider: AIProvider | undefined;
    buildContext: ((ctx: Ctx, instruction: string) => AIPromptContext) | undefined;
    diffReviewOnEnd: boolean;
    onError: (error: MilkdownError) => void;
    aiIcon: string | undefined;
}, "aiProviderConfig">;
export declare const aiSessionCtx: import("@milkdown/utils").$Ctx<{
    abortController: AbortController | null;
    label: string;
    lastInstruction: string;
    lastLabel: string | undefined;
    lastFrom: number;
    lastTo: number;
    diffOwnedByAI: boolean;
}, "aiSession">;
export declare const runAICmd: import("@milkdown/utils").$Command<RunAIOptions>;
export declare const abortAICmd: import("@milkdown/utils").$Command<{
    keep?: boolean;
}>;
//# sourceMappingURL=commands.d.ts.map