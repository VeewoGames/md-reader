import type { Ctx } from '@milkdown/kit/ctx';
import type { AIPromptContext } from './types';
export declare function defaultBuildContext(ctx: Ctx, instruction: string): AIPromptContext;
//# sourceMappingURL=context.d.ts.map