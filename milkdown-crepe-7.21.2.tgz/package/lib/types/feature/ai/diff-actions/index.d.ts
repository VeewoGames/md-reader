import type { AIDiffActionsConfig } from '../types';
export declare const DEFAULT_DIFF_ACTIONS_RETRY_LABEL = "Retry";
export declare const DEFAULT_DIFF_ACTIONS_REJECT_ALL_LABEL = "Reject all";
export declare const DEFAULT_DIFF_ACTIONS_ACCEPT_ALL_LABEL = "Accept all";
export declare const DEFAULT_DIFF_ACTIONS_MOD_SYMBOL: string;
interface DiffActionsPluginOptions {
    config?: AIDiffActionsConfig;
    enterKeyIcon?: string;
}
export declare function diffActionsPanelPlugin(options?: DiffActionsPluginOptions): import("@milkdown/utils").$Prose;
export {};
//# sourceMappingURL=index.d.ts.map