import type { Ctx } from '@milkdown/kit/ctx';
import type { PluginView } from '@milkdown/kit/prose/state';
import type { EditorView } from '@milkdown/kit/prose/view';
export interface ResolvedDiffActionsConfig {
    retryLabel: string;
    rejectAllLabel: string;
    acceptAllLabel: string;
    retryIcon: string;
    rejectIcon: string;
    acceptIcon: string;
    enterKeyIcon: string;
    modSymbol: string;
}
export declare class DiffActionsPanelView implements PluginView {
    #private;
    readonly ctx: Ctx;
    constructor(ctx: Ctx, view: EditorView, config: ResolvedDiffActionsConfig);
    update(view: EditorView): void;
    destroy(): void;
}
//# sourceMappingURL=view.d.ts.map