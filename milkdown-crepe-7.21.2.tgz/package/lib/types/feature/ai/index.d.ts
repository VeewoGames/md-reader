import type { DefineFeature } from '../shared';
import type { AIFeatureConfig } from './types';
export type { AIDiffActionsConfig, AIFeatureConfig, AIPromptContext, AIProvider, AIStreamingIndicatorConfig, AISubmenuBuilder, AISubmenuDef, AISuggestionItem, AISuggestionsBuilder, } from './types';
export { runAICmd, abortAICmd } from './commands';
export { defaultBuildContext } from './context';
export declare const ai: DefineFeature<AIFeatureConfig>;
//# sourceMappingURL=index.d.ts.map