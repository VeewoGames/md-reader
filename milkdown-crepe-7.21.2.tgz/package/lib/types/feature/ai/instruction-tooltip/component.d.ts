import { type Ref } from 'vue';
import type { AISuggestionItem, ResolvedSuggestions } from './suggestions';
export interface AIInstructionTooltipChrome {
    aiIcon: string;
    sendIcon: string;
    sendPromptIcon: string;
    enterKeyIcon: string;
    chevronLeftIcon: string;
    chevronRightIcon: string;
    suggestionsHeaderLabel: string;
    sendAsPromptHeaderLabel: string;
    sendAsPromptLabel: string;
    submitButtonLabel: string;
    listboxLabel: string;
}
type AIInstructionInputProps = {
    placeholder: Ref<string>;
    resetSignal: Ref<number>;
    suggestions: ResolvedSuggestions;
    chrome: AIInstructionTooltipChrome;
    onConfirm: (instruction: string, label?: string) => void;
    onCancel: () => void;
};
export declare const AIInstructionInput: import("vue").DefineComponent<AIInstructionInputProps, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<AIInstructionInputProps> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export type { AISuggestionItem };
//# sourceMappingURL=component.d.ts.map