import type { Ctx } from '@milkdown/kit/ctx';
import type { AIFeatureConfig } from '../types';
export interface AIInstructionTooltipAPI {
    show: (from: number, to: number) => void;
}
export declare const aiInstructionTooltipAPI: import("@milkdown/utils").$Ctx<{
    show: (from: number, to: number) => void;
}, "aiInstructionTooltipAPI">;
export declare const aiInstructionTooltip: import("@milkdown/plugin-tooltip").TooltipPlugin<"CREPE_AI_INSTRUCTION", any>;
export declare const DEFAULT_SUGGESTIONS_HEADER_LABEL = "SUGGESTIONS";
export declare const DEFAULT_SEND_AS_PROMPT_HEADER_LABEL = "SEND AS PROMPT";
export declare const DEFAULT_SEND_AS_PROMPT_LABEL = "Ask AI:";
export declare const DEFAULT_SUBMIT_BUTTON_LABEL = "Send prompt";
export declare const DEFAULT_LISTBOX_LABEL = "AI suggestions";
export declare const DEFAULT_INSTRUCTION_PLACEHOLDER = "Tell AI what to do with the selection\u2026";
export declare function configureAIInstructionTooltip(config?: AIFeatureConfig): (ctx: Ctx) => void;
//# sourceMappingURL=index.d.ts.map