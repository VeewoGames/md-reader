export interface AISuggestionItem {
    icon: string;
    label: string;
    streamingLabel?: string;
    prompt: string;
}
export interface AISubmenuDef {
    icon: string;
    label: string;
    title: string;
    searchPlaceholder: string;
}
export interface AISubmenuBuilder {
    addItem: (id: string, item: AISuggestionItem) => AISubmenuBuilder;
    removeItem: (id: string) => AISubmenuBuilder;
    getItem: (id: string) => AISuggestionItem | undefined;
    clear: () => AISubmenuBuilder;
}
export type ResolvedItemEntry = {
    kind: 'item';
    id: string;
    item: AISuggestionItem;
};
export type ResolvedSubmenuEntry = {
    kind: 'submenu';
    id: string;
    def: AISubmenuDef;
};
export interface ResolvedSuggestions {
    main: Array<ResolvedItemEntry | ResolvedSubmenuEntry>;
    submenus: Record<string, {
        def: AISubmenuDef;
        items: Array<{
            id: string;
            item: AISuggestionItem;
        }>;
    }>;
}
export declare class AISuggestionsBuilder {
    #private;
    addItem: (id: string, item: AISuggestionItem) => this;
    addSubmenu: (id: string, def: AISubmenuDef, build?: (sub: AISubmenuBuilder) => void) => this;
    removeItem: (id: string) => this;
    getItem: (id: string) => AISuggestionItem | undefined;
    getSubmenu: (id: string) => AISubmenuBuilder | undefined;
    clear: () => this;
    build: () => ResolvedSuggestions;
}
export declare function applyDefaultSuggestions(builder: AISuggestionsBuilder): void;
//# sourceMappingURL=suggestions.d.ts.map