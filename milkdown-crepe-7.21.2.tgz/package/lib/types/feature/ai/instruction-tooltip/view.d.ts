import type { Ctx } from '@milkdown/kit/ctx';
import type { EditorState, PluginView } from '@milkdown/kit/prose/state';
import type { EditorView } from '@milkdown/kit/prose/view';
import type { ResolvedSuggestions } from './suggestions';
import { type AIInstructionTooltipChrome } from './component';
export interface AIInstructionTooltipViewConfig {
    placeholder: string;
    chrome: AIInstructionTooltipChrome;
    suggestions: ResolvedSuggestions;
}
export declare class AIInstructionTooltipView implements PluginView {
    #private;
    readonly ctx: Ctx;
    constructor(ctx: Ctx, view: EditorView, config: AIInstructionTooltipViewConfig);
    show: (from: number, to: number) => void;
    update: (view: EditorView, prevState?: EditorState) => void;
    destroy: () => void;
}
//# sourceMappingURL=view.d.ts.map