import type { AIStreamingIndicatorConfig } from './types';
export declare const DEFAULT_STREAMING_FALLBACK_LABEL = "Generating";
export declare const DEFAULT_STREAMING_CANCEL_HINT = "Esc to cancel";
interface StreamingIndicatorPluginOptions {
    config?: AIStreamingIndicatorConfig;
}
export declare function streamingIndicatorPlugin(options?: StreamingIndicatorPluginOptions): import("@milkdown/utils").$Prose;
export {};
//# sourceMappingURL=streaming-indicator.d.ts.map