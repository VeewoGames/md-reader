import type { Ctx } from '@milkdown/kit/ctx';
import type { MilkdownError } from '@milkdown/kit/exception';
import type { StreamingConfig } from '@milkdown/kit/plugin/streaming';
import type { AISuggestionsBuilder } from './instruction-tooltip/suggestions';
export type { AISubmenuBuilder, AISubmenuDef, AISuggestionItem, AISuggestionsBuilder, } from './instruction-tooltip/suggestions';
export interface AIPromptContext {
    document: string;
    selection: string;
    instruction: string;
}
export type AIProvider = (context: AIPromptContext, signal: AbortSignal) => AsyncIterable<string>;
export interface AIDiffConfig {
    acceptLabel?: string;
    rejectLabel?: string;
    customBlockTypes?: string[];
    ignoreAttrs?: Record<string, string[]>;
}
export interface AIStreamingIndicatorConfig {
    fallbackLabel?: string;
    cancelHint?: string;
}
export interface AIDiffActionsConfig {
    retryLabel?: string;
    rejectAllLabel?: string;
    acceptAllLabel?: string;
    retryIcon?: string;
    rejectIcon?: string;
    acceptIcon?: string;
    modSymbol?: string;
}
export interface AIFeatureConfig {
    provider?: AIProvider;
    buildContext?: (ctx: Ctx, instruction: string) => AIPromptContext;
    diffReviewOnEnd?: boolean;
    diff?: AIDiffConfig;
    streaming?: Partial<Omit<StreamingConfig, 'diffReviewOnEnd'>>;
    onError?: (error: MilkdownError) => void;
    aiIcon?: string;
    instructionPlaceholder?: string;
    suggestionsHeaderLabel?: string;
    sendAsPromptHeaderLabel?: string;
    sendAsPromptLabel?: string;
    submitButtonLabel?: string;
    listboxLabel?: string;
    sendIcon?: string;
    sendPromptIcon?: string;
    enterKeyIcon?: string;
    chevronLeftIcon?: string;
    chevronRightIcon?: string;
    buildAISuggestions?: (builder: AISuggestionsBuilder) => void;
    streamingIndicator?: AIStreamingIndicatorConfig;
    diffActions?: AIDiffActionsConfig;
}
export interface RunAIOptions {
    instruction: string;
    label?: string;
}
//# sourceMappingURL=types.d.ts.map