export declare const mathInlineId = "math_inline";
export declare const toggleLatexCommandName = "ToggleLatex";
//# sourceMappingURL=constants.d.ts.map