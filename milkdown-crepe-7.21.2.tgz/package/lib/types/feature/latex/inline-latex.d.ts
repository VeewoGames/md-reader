import { mathInlineId } from './constants';
export { mathInlineId };
export declare const mathInlineSchema: import("@milkdown/utils").$NodeSchema<"math_inline">;
//# sourceMappingURL=inline-latex.d.ts.map