import '@testing-library/jest-dom/vitest';
//# sourceMappingURL=inline-tooltip.spec.d.ts.map