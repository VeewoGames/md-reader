import '@testing-library/jest-dom/vitest';
//# sourceMappingURL=link-tooltip.spec.d.ts.map