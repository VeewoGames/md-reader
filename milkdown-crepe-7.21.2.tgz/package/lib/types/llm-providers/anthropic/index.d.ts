import type { AIPromptContext, AIProvider } from '../../feature/ai/types';
import { type BaseProviderConfig } from '../shared';
export interface AnthropicMessage {
    role: 'user' | 'assistant';
    content: string;
}
export interface AnthropicBuildMessagesResult {
    system?: string;
    messages: AnthropicMessage[];
}
export interface AnthropicProviderConfig extends BaseProviderConfig {
    maxTokens?: number;
    anthropicVersion?: string;
    buildMessages?: (context: AIPromptContext, defaults: {
        systemPrompt: string | null;
        userMessage: string;
    }) => AnthropicBuildMessagesResult;
    body?: Record<string, unknown>;
}
export declare function createAnthropicProvider(config: AnthropicProviderConfig): AIProvider;
//# sourceMappingURL=index.d.ts.map