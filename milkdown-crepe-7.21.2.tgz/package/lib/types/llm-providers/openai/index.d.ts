import type { AIPromptContext, AIProvider } from '../../feature/ai/types';
import { type BaseProviderConfig } from '../shared';
export interface OpenAIChatMessage {
    role: 'system' | 'user' | 'assistant';
    content: string;
}
export interface OpenAIProviderConfig extends BaseProviderConfig {
    buildMessages?: (context: AIPromptContext, defaults: {
        systemPrompt: string | null;
        userMessage: string;
    }) => OpenAIChatMessage[];
    body?: Record<string, unknown>;
}
export declare function createOpenAIProvider(config: OpenAIProviderConfig): AIProvider;
//# sourceMappingURL=index.d.ts.map