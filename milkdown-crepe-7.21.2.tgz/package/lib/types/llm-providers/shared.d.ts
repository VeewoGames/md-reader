import type { AIPromptContext } from '../feature/ai/types';
export declare const DEFAULT_SYSTEM_PROMPT = "You are a writing assistant embedded in a markdown editor.\n\nRules:\n- Output markdown only. Never wrap your output in code fences (e.g. ```markdown ... ```).\n- Never include preambles, explanations, or sign-offs \u2014 output only the edited or generated content itself.\n- Preserve the original markdown structure (headings, lists, links, code blocks) unless the instruction explicitly asks to change it.\n- If a <selection> is provided, return only the replacement for that selection \u2014 do not repeat surrounding document context.\n- If no <selection> is provided, return content to insert at the cursor that flows with the surrounding document.";
export declare function buildDefaultUserMessage(context: AIPromptContext): string;
export interface BaseProviderConfig {
    apiKey?: string;
    baseURL?: string;
    headers?: Record<string, string>;
    model: string;
    systemPrompt?: string | null;
    dangerouslyAllowBrowser?: boolean;
}
export declare function assertBrowserSafe(config: BaseProviderConfig, providerName: string): void;
export declare function resolveSystemPrompt(systemPrompt: string | null | undefined): string | null;
export declare function stripTrailingSlashes(url: string): string;
export declare function parseSSE(response: Response, signal: AbortSignal): AsyncGenerator<string>;
export declare function readErrorBody(response: Response, providerName: string): Promise<Error>;
//# sourceMappingURL=shared.d.ts.map